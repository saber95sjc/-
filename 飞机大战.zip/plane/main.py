import pygame
from bullet import Bullet 
from plane import Plane
from enemy import Enemy
from pygame.locals import *
from sys import exit
from game_function import *
import time


pygame.init() #初始化游戏 
screen = pygame.display.set_mode((480,800)) #创建窗口
pygame.display.set_caption("打飞机") #设置标题
background = pygame.image.load('images/background1.gif').convert()#加载背景图片
gameover_image = pygame.image.load('images/gameover.gif').convert()#加载游戏结束图片
restart_image = pygame.image.load('images/start_label.gif').convert()#加载开始图片

while True:
    gameover = False#记录游戏结束过？？
    pressed = False#记录按压鼠标事件
    fashe_time=0#计算发射时间
    score = 0#记录分数
    fclock = pygame.time.Clock()
    index=0#记录子弹的序号
    font=pygame.font.Font(None,32)  #创建一个font对象,None表示使用默认字体，32是字号
    plane = Plane() #创建一个飞机实例
    #创建多个子弹
    bullets = create_bullets()
    enemys = create_enemys()

    while True:
        for event in pygame.event.get(): #生成器
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == MOUSEBUTTONDOWN:
                mousex,mousey = pygame.mouse.get_pos()
                pressed_array = pygame.mouse.get_pressed()
                if pressed_array[0] and(mousex>140 and mousex<350 and mousey>380 and mousey<420):
                    pressed = True


        screen.blit(background,(0,0)) #将背景画到屏幕上

        if not gameover:
            # x,y = pygame.mouse.get_pos() #获取鼠标的坐标
            fashe_time -= 1
            if fashe_time < 0:
                #激活子弹
                bullets[index].restart(plane)
                #重置发射时间
                fashe_time = 30
                index += 1
                index = index % len(bullets)
            score = print_bullet(screen,bullets,enemys,score)
            text=font.render("Score: %d" % score,1,(0,0,0))
            screen.blit(text,(0,0))
            
            gameover = print_enemy(screen,enemys,plane,gameover)
            plane.move()
            screen.blit(plane.get_image(),plane.get_x_y())#将飞机画到屏幕上
        else:
            if pressed:
                break
            else:
                screen.blit(gameover_image,(40,0))#游戏结束界面画到屏幕上
                screen.blit(restart_image,(140,380))#开始图片画到屏幕上
                text=font.render("Score: %d" % score,1,(0,0,0))
                screen.blit(text,(190,330))
        pygame.display.update()
        fclock.tick(100)