# game_function.py
import pygame

from bullet import Bullet 
from plane import Plane
from enemy import Enemy
from pygame.locals import *

#子弹碰到敌人
def bullet_hit(bullet,enemy):
    if(bullet.get_x()>enemy.get_x() and bullet.get_x() < enemy.get_x() + enemy.get_image().get_width()) and (bullet.get_y() <= enemy.get_y() + enemy.get_image().get_height() and bullet.get_y() > enemy.get_y()):
        enemy.restart()
        bullet.set_active(False)
        return True

#敌人碰到飞机
def plane_hit(enemy,plane):    #敌机碰飞机
    if((plane.get_x()+0.7*plane.get_image().get_width()>enemy.get_x())
        and (plane.get_x()+0.3*plane.get_image().get_width() < enemy.get_x()+enemy.get_image().get_width())
        and (plane.get_y()+0.7*plane.get_image().get_height()>enemy.get_y())
        and (plane.get_y()+0.3*plane.get_image().get_height()<enemy.get_y()+enemy.get_image().get_height())):
        return True
    return False

def print_bullet(screen,bullets,enemys,score1):
    for b in bullets:
        if b.get_active():
            for e in enemys:
                if bullet_hit(b,e):
                    score1 += 100
            b.move()
            screen.blit(b.get_image(),b.get_x_y())#将子弹画到屏幕上
    return score1

def print_enemy(screen,enemys,plane,gameover):
    for e in enemys:
        if plane_hit(e,plane):
            gameover = True
        e.move()
        screen.blit(e.get_image(),e.get_x_y())#将敌人画到屏幕上
    return gameover

def create_enemys():
    enemys = []
    for i in range(5):
        enemy = Enemy() #创建一个敌人
        enemys.append(enemy)
    return enemys


def create_bullets():
    bullets = []
    for i in range(5):
        bullet1 = Bullet() #创建一个子弹实例
        bullets.append(bullet1)
    return bullets

def plane_move(plane,event):
    # for event in pygame.event.get():
        # if event.type == pygame.K_UP:
    speed = 5
    if event.type == pygame.K_UP:
        y = plane.get_y() + speed
        plane.set_y(y)
    if event.type == pygame.K_DOWN:
        y = plane.get_y() - speed
        plane.set_y(y)
    if event.type == pygame.K_RIGHT:
        x = plane.get_x() + speed
        plane.set_x(x)
    if event.type == pygame.K_LEFT:
        x = plane.get_x() - speed
        plane.set_x(x)
    return plane

    