# enemy.py  创建敌人类

import pygame
from pygame.locals import *
import random

class Enemy:

    def __init__(self):
        self.restart()
        self.enemy_image = pygame.image.load('images/smallplane8.gif').convert()

    def restart(self):
        self.x = random.randint(40,440)
        self.y = random.randint(-100,-50)
        self.speed = random.random()+0.1

    def get_image(self):
        return self.enemy_image

    def get_x(self):
        return self.x
    def get_y(self):
        return self.y
    #获取敌人位置坐标
    def get_x_y(self):
        return (self.x,self.y)

    #敌人移动
    def move(self):
        if self.y<800:
            #向下移动
            self.y += self.speed
        else:
            #重置敌人位置
            self.restart()
