# bullet.py 子弹类

import pygame
from pygame.locals import *

class Bullet:
    '''封装子弹相关数据'''
    def __init__(self):
        self.x = 0
        self.y = -1
        self.bullet_image = pygame.image.load('images/bullet.gif').convert_alpha()
        #默认不激活
        self.active = False

    def move(self):
        #如果激活向下移动
        if self.active:
            self.y -= 5
        #超出屏幕则不激活
        if self.y < 0:
            self.active = False

    def get_image(self):
        return self.bullet_image

    def get_x(self):
        return self.x
    def get_y(self):
        return self.y

    def get_x_y(self):
        return (self.x,self.y)

    def get_active(self):
        return self.active

    def set_active(self,active):
        self.active = active

    def restart(self,plane):
        # mouse_x ,mouse_y = pygame.mouse.get_pos()
        self.x = plane.get_x() + plane.get_image().get_width()/2-self.bullet_image.get_width()/2
        self.y = plane.get_y() + plane.get_image().get_height()/2-self.bullet_image.get_height()/2
        keys = pygame.key.get_pressed()
        speed = 5
        if keys[K_UP]:
            self.y = self.y - speed
        if keys[K_DOWN]:
            self.y = self.y + speed
        if keys[K_RIGHT]:
            self.x = self.x + speed
        if keys[K_LEFT]:
            self.x = self.x - speed
        self.active = True