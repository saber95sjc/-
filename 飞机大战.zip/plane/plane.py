# plane.py  创建飞机类

import pygame
from pygame.locals import *

class Plane:
    def __init__(self):
        self.x = 240
        self.y = 600
        self.plane_image = pygame.image.load('images/hero.gif').convert()

    def move(self):
        keys = pygame.key.get_pressed()
        speed = 5
        if keys[K_UP]:
            self.y = self.y - speed
        if keys[K_DOWN]:
            self.y = self.y + speed
        if keys[K_RIGHT]:
            self.x = self.x + speed
        if keys[K_LEFT]:
            self.x = self.x - speed
        if self.x >383:
            self.x = 383
        if self.x<0:
            self.x = 0
        if self.y > 726:
            self.y = 726
        if self.y < 0:
            self.y = 0

    def get_x(self):
        return self.x
    def get_y(self):
        return self.y

    def set_x(x):
        self.x = x
    def set_y(y):
        self.y = y

    def get_x_y(self):
        return (self.x,self.y)

    def get_image(self):
        return self.plane_image